package craps;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Registrarse extends JPanel {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Create the panel.
	 */
	public Registrarse() {
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nombre usuario:");
		lblNewLabel.setBounds(101, 36, 82, 14);
		add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(188, 33, 96, 20);
		add(textField);
		textField.setColumns(10);
		
		JLabel lblContrasea = new JLabel("Contrasena:");
		lblContrasea.setBounds(123, 64, 60, 14);
		add(lblContrasea);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(188, 61, 96, 20);
		add(textField_1);
		
		JLabel lblSaldoDisponible = new JLabel("Saldo disponible:");
		lblSaldoDisponible.setBounds(103, 92, 90, 14);
		add(lblSaldoDisponible);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(188, 89, 96, 20);
		add(textField_2);
		
		JButton btnNewButton = new JButton("Registrarse");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnNewButton.setBounds(151, 148, 89, 23);
		add(btnNewButton);

	}

}
