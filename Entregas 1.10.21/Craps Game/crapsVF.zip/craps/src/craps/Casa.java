package craps;

public class Casa {

}
