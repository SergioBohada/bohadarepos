package co_RelojDigital_UD;

import java.util.concurrent.TimeUnit;

public class Reloj {

	Min minut = new Min(60, 0);
	Seg segnd = new Seg(60, 0);
	Hora hora = new Hora(12, 0);

	
	public String viz() {
		
		return String.valueOf(hora.getValor()+":"+minut.getValor()+":"+segnd.getValor()); 
	}
	public void avanzarReloj() {
		if (segnd.getValor() == segnd.getLimite() - 1) {

			try {
				Thread.sleep(1000);
				segnd.Avanzar();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			if (minut.getValor() == minut.getLimite() - 1) {

				hora.Avanzar();

			}
			minut.Avanzar();

		} else {

			try {
				Thread.sleep(1000);
				segnd.Avanzar();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
		}
		
		
	}

	public void Reiniciar() {

		segnd.setValor(0);
		minut.setValor(0);
		hora.setValor(0);

	}


}
