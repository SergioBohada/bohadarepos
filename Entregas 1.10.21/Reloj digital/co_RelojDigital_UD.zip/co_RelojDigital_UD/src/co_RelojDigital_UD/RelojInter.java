package co_RelojDigital_UD;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.UIManager;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class RelojInter {

	Reloj rlj = new Reloj();	
	private JFrame frame;
	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	private boolean pause = false;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RelojInter window = new RelojInter();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		
	}

	/**
	 * Create the application.
	 */
	public RelojInter() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(100, 100, 573, 763);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setUndecorated(true);
		frame.setBackground(new Color(1.0f,1.0f,1.0f,0.0f));
		frame.getContentPane().setLayout(null);
		
		
		
		
		JLabel lblNewLabel = new JLabel("00:00:00", SwingConstants.CENTER);
		lblNewLabel.setBackground(new Color(102, 102, 102));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Microsoft JhengHei Light", Font.PLAIN, 30));
		lblNewLabel.setBounds(72, 274, 225, 107);
		frame.getContentPane().add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.BLACK);
		panel_1.setBounds(80, 280, 210, 90);
		frame.getContentPane().add(panel_1);
		
		JPanel panel = new JPanel();
		panel.setBounds(72, 274, 225, 107);
		panel.setBackground(new Color(115,115,115));
		frame.getContentPane().add(panel);
		
		JButton btnNewButton = new JButton("Iniciar");
		btnNewButton.setIcon(null);
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 8));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pause = false;
				new Thread(() -> {
		            // here goes your current code
					while(!pause) {
						
						rlj.avanzarReloj();
						lblNewLabel.setText(rlj.viz());
						System.out.println(rlj.viz());
					}
		        }).start();
								
				
			}
		});
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(new Color(170,170,170));
		btnNewButton.setBounds(72, 381, 75, 23);
		btnNewButton.setBorderPainted(false);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Pausa/Cont");
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 8));
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.setBackground(new Color(170,170,170));
		btnNewButton_1.setBounds(147, 381, 75, 23);
		frame.getContentPane().add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pause = true;
			}
		});
		
		JButton btnNewButton_2 = new JButton("Reiniciar");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pause = true;
				rlj.Reiniciar();
				//JLabel lblNewLabel = new JLabel("00:00:00", SwingConstants.CENTER);
				lblNewLabel.setText("00:00:00");
				
						}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 8));
		btnNewButton_2.setForeground(Color.WHITE);
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setBackground(new Color(170,170,170));
		btnNewButton_2.setBounds(222, 381, 75, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(90, 90, 90));
		panel_2.setBounds(80, 263, 225, 107);
		frame.getContentPane().add(panel_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(230, 370, 75, 23);
		panel_3.setBackground(new Color(140,140,140));
		frame.getContentPane().add(panel_3);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(157, 403, 37, 26);
		frame.getContentPane().add(panel_4);
		
		JPanel panel_4_1 = new JPanel();
		panel_4_1.setBounds(175, 392, 37, 37);
		panel_4_1.setBackground(new Color(210,210,210));
		frame.getContentPane().add(panel_4_1);
		
		
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(RelojInter.class.getResource("/co_RelojDigital_UD/anime-lofi.gif")));
		lblNewLabel_1.setBounds(0, 0, 381, 428);
		frame.getContentPane().add(lblNewLabel_1);
		
		
	}
}
