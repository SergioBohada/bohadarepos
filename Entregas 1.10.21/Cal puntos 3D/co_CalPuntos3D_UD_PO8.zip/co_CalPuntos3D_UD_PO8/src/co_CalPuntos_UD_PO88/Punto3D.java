package co_CalPuntos_UD_PO88;

import java.util.Scanner;

public class Punto3D {
	
	private double x;
    private double y;
    private double z;

    public Punto3D(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public double getX() {
        return this.x;
    }

    public double getY() {
        return this.y;
    }
    public double getZ() {
    	
    	return this.z;
    	
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }
    
    public void setZ(double z) {
    	
    	this.z = z;
    }
    public void imprimir() {
        System.out.println("("+this.x+")"+","+"("+this.y+")"+","+"("+this.z+")");
    }

    public String dist(Punto3D c1, Punto3D c2) {
        
        

        return String.valueOf(Math.sqrt(Math.pow(c1.x-c2.x,2) + (Math.pow(c1.y-c2.y, 2)+ (Math.pow(c1.z-c2.z, 2)))));

    }
    
    public double distOri(Punto3D c1) {
    	
    	return (Math.sqrt(Math.pow(c1.x,2) + (Math.pow(c1.y, 2)+ (Math.pow(c1.z, 2))))
    			
    			);
    }

    

    public String  moverX(Punto3D c1, double var) {
    	
    	c1.x += var;
    	
    	return String.valueOf(c1.x);

    }

    public String  moverY(Punto3D c1, double var) {
    	
    	c1.y += var;
    	
    	return String.valueOf(c1.y);

    }
    
    public String  moverZ(Punto3D c1, double var) {
    	
    	c1.z += var;
    	
    	return String.valueOf(c1.z);

    }
    public String  moverXYZ(Punto3D c1, double var,double var1,double var2) {
    	
    	c1.x += var;
    	c1.y += var1;
    	c1.z += var2;
    	
    	
    	return String.valueOf("("+c1.x+","+c1.y+","+c1.z+")");

    }


}
