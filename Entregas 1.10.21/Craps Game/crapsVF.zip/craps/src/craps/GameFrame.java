package craps;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;

public class GameFrame extends JFrame {

	private JPanel contentPane;
	private JTextField textApu;
	private Jugador jugador;
	private Juego juego;
	//GameFrame frame;

	/**
	 * Launch the application.
	 */
	/*
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GameFrame frame = new GameFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public GameFrame(String nomb, String psw, double disp) {
		//frame = new GameFrame();
		jugador = new Jugador(nomb, psw, disp);
		juego = new Juego(nomb, psw, disp);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		getContentPane().setLayout(null);
		contentPane.setLayout(null);

		JLabel lblDisp = new JLabel("$ Disponible:");
		lblDisp.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblDisp.setForeground(Color.WHITE);
		lblDisp.setBounds(25, 11, 85, 14);
		getContentPane().add(lblDisp);

		JLabel lblDispVal = new JLabel("New label");
		lblDispVal.setForeground(Color.WHITE);
		lblDispVal.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblDispVal.setBounds(120, 11, 49, 14);
		getContentPane().add(lblDispVal);
		lblDispVal.setText(jugador.getSaldo()+"");

		JLabel lblJugador = new JLabel("Jugador");
		lblJugador.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblJugador.setForeground(Color.WHITE);
		lblJugador.setBounds(313, 11, 99, 14);
		getContentPane().add(lblJugador);
		lblJugador.setText(jugador.getNombre());

		JLabel lblApu = new JLabel("Apuesta:");
		lblApu.setForeground(Color.WHITE);
		lblApu.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblApu.setBounds(35, 83, 75, 14);
		getContentPane().add(lblApu);

		JLabel lblDados = new JLabel("Resultados:");
		lblDados.setForeground(Color.WHITE);
		lblDados.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblDados.setBounds(216, 83, 85, 14);
		getContentPane().add(lblDados);

		textApu = new JTextField();
		textApu.setBounds(120, 80, 49, 20);
		getContentPane().add(textApu);
		textApu.setColumns(10);

		JLabel lblDadosVal = new JLabel("");
		lblDadosVal.setBounds(324, 83, 49, 14);
		getContentPane().add(lblDadosVal);

		JLabel lblRondaVal = new JLabel("");
		lblRondaVal.setBounds(120, 153, 49, 14);
		getContentPane().add(lblRondaVal);

		JLabel lblRonda = new JLabel("Ronda #");
		lblRonda.setForeground(Color.WHITE);
		lblRonda.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblRonda.setBounds(48, 153, 75, 14);
		getContentPane().add(lblRonda);

		JButton btnNewButton = new JButton("Siguiente ronda");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String apuesta = textApu.getText();
				double ap = Double.parseDouble(apuesta);
				String dados = juego.jugarRonda(ap);
				lblDadosVal.setText(dados);
				jugador = juego.getJugador();
				lblDispVal.setText(jugador.getSaldo()+"");
				lblRondaVal.setText(juego.getRonda()+"");

			}
		});
		btnNewButton.setBounds(35, 214, 147, 20);
		getContentPane().add(btnNewButton);

		JButton btnRetirarse = new JButton("Retirarse");
		btnRetirarse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(getContentPane(), "Juego Finalizado. Total ganancias: $"+juego.getGanancias());
			}
		});
		btnRetirarse.setBounds(211, 213, 147, 20);
		getContentPane().add(btnRetirarse);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(GameFrame.class.getResource("/craps/Casbk1.jpg")));
		lblNewLabel.setBounds(0, 0, 436, 263);
		contentPane.add(lblNewLabel);

	}
}
