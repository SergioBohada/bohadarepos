package craps;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import java.awt.Color;

public class SignUpFrame extends JFrame {
	
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	private JPanel contentPane;
	private static SignUpFrame frame;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new SignUpFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public SignUpFrame() {
		frame = this;
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		this.setVisible(true);
		
		JLabel lblNewLabel = new JLabel("Nombre usuario:");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(67, 36, 116, 14);
		getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(188, 33, 96, 20);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblContrasea = new JLabel("Contrasena:");
		lblContrasea.setForeground(Color.WHITE);
		lblContrasea.setBounds(101, 64, 82, 14);
		getContentPane().add(lblContrasea);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(188, 61, 96, 20);
		getContentPane().add(textField_1);
		
		JLabel lblSaldoDisponible = new JLabel("Saldo disponible:");
		lblSaldoDisponible.setForeground(Color.WHITE);
		lblSaldoDisponible.setBounds(67, 92, 126, 14);
		getContentPane().add(lblSaldoDisponible);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(188, 89, 96, 20);
		getContentPane().add(textField_2);
		
		JButton btnNewButton = new JButton("Registrarse");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				new GameFrame(textField.getText(), textField_1.getText(),Double.parseDouble(textField_2.getText()));
			}
		});
		btnNewButton.setBounds(139, 133, 126, 31);
		getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(SignUpFrame.class.getResource("/craps/fondo.jpg")));
		lblNewLabel_1.setBounds(0, 0, 450, 300);
		contentPane.add(lblNewLabel_1);


	}

}
