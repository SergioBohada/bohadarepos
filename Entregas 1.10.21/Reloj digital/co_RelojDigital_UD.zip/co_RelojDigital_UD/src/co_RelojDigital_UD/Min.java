package co_RelojDigital_UD;

public class Min extends UT{
	
	
	
	public Min(int limite, int valor) {
		super(limite, valor);
		
	}

}
