package craps;

public class Juego {

	private int turno;
	private int primerLanzamiento;
	private double apuesta;
	Jugador jugador;
	private int ganancias = 0;
	
	
	public int lanzarDados() {
		
		int dado1 = (int) ((Math.random() * (6 - 1)) + 1);
		int dado2 = (int) ((Math.random() * (6 - 1)) + 1);
		
		return dado1 + dado2;
	}
	
	public Juego(String nombJug, String conJug, double total) {
		jugador = new Jugador(nombJug, conJug, total);
		this.turno = 0;
	}
	
	public String jugarRonda(double apuesta) {
		//boolean gano= false;
		
		this.apuesta = apuesta;
		int res=0;
		System.out.println("Turno"+ turno);
		if(jugador.getSaldo()>= apuesta) {
			res  = lanzarDados();
			if(turno==0) {
				if(res==7 || res==11) {
					//gano = true;
					jugador.setSaldo(apuesta);
					ganancias+=apuesta;
					
				} else if(res==2 || res==3 || res==12){
					jugador.setSaldo(-apuesta);
					ganancias-=apuesta;
				} else {
					turno++;
					this.primerLanzamiento = res;
				}
			} else {
				if(res == this.primerLanzamiento) {
					jugador.setSaldo(apuesta);
					ganancias+=apuesta;
					this.turno= 0;
				} else if(res == 7) {
					jugador.setSaldo(-apuesta);
					ganancias-=apuesta;
					this.turno= 0;
				} else {
					turno++;
				}
			}
			
		} else {
			
			System.out.println("No tiene saldo suficiente");
		}
		System.out.println("Dados"+res);
		
		System.out.println("Saldo"+jugador.getSaldo());
		
		return res+"";
		
	}
	
	public Jugador getJugador() {
		return jugador;
	}
	
	public int getRonda() {
		return turno;
	}
	
	public int getGanancias() {
		return this.ganancias;
	}
	
	
}
