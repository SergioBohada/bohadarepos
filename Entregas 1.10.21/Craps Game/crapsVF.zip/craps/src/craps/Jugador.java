package craps;

public class Jugador {

	private String nombre;
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getContrasena() {
		return contrasena;
	}

	public void setContrasena(String contrasena) {
		this.contrasena = contrasena;
	}

	private String contrasena;
	private double saldo;
	
	Jugador(String nombre, String contrasena, double saldo){
		this.nombre = nombre;
		this.contrasena = contrasena;
		this.saldo = saldo;
	}
	
	public void setSaldo(double newSaldo) {
		this.saldo += newSaldo;
	}
	
	public double getSaldo() {
		return this.saldo;
	}
	
	
}
