package co_RelojDigital_UD;

public class Seg extends UT{
	
	public Seg(int limite, int valor) {
		super(limite, valor);
		
	}

}
