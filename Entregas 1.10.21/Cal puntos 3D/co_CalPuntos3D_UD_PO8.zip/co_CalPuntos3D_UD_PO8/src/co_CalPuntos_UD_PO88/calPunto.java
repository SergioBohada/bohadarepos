package co_CalPuntos_UD_PO88;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;

public class calPunto {

	private JFrame frame;
	private JTextField textField;
	private JLabel lblNewLabel;
	private JPanel panel;
	private JPanel panel_1;
	private JPanel panel_2;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;
	private JButton btnDistancia;
	private JButton btnDistanciaAlOrigen;
	private JButton btnClear;
	private String num1s;
	private double num1d;
	private String num2s;
	private double num2d;
	private String num1is;
	private double num1id;
	private String num2is;
	private double num2id;
	private String num3is;
	private double num3id;
	private String num4is;
	private double num4id;
	private String num5is;
	private double num5id;
	private int cont = 0;
	private JButton btnNewButton_3;
	private JPanel panel_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					calPunto window = new calPunto();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public calPunto() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(204, 204, 204));
		
		
		frame.setBounds(100, 100, 400, 434);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setUndecorated(true);
		frame.setBackground(new Color(1.0f,1.0f,1.0f,0.0f));
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBackground(new Color(153, 51, 51));
		textField.setForeground(new Color(255, 255, 255));
		textField.setBounds(276, 90, 110, 25);
		textField.setBorder(null);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		lblNewLabel = new JLabel("Escoja una operaci�n", SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Microsoft JhengHei Light", Font.PLAIN, 16));
		lblNewLabel.setBackground(new Color(102, 153, 0));
		lblNewLabel.setBounds(50, 11, 188, 104);
		frame.getContentPane().add(lblNewLabel);
		
		panel = new JPanel();
		panel.setBackground(new Color(255, 75, 75));
		panel.setBounds(10, 11, 267, 104);
		frame.getContentPane().add(panel);
		
		panel_1 = new JPanel();
		panel_1.setBounds(276, 11, 110, 80);
		panel_1.setBackground(new Color(255, 75, 75));
		frame.getContentPane().add(panel_1);
		panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 90, 90));
		panel_2.setBounds(10, 115, 376, 25);
		frame.getContentPane().add(panel_2);
		
		btnNewButton = new JButton("Mover en x");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lblNewLabel.setText("Introducir valor en x");
				lblNewLabel.setFont(new Font("Microsoft JhengHei Light", Font.PLAIN, 12));

				textField.addKeyListener(new KeyAdapter() {
					@Override
					public void keyPressed(KeyEvent e) {

						if (e.getKeyCode() == KeyEvent.VK_ENTER) {
							System.out.println("Entre event key"+cont);
							// Enter was pressed. Your code goes here.
							if (cont == 0) {
								
								num1s = textField.getText();
								num1d = Double.parseDouble(num1s);
								textField.setText("");
								lblNewLabel.setText("Introducir valor en y");

							} else if (cont == 1) {

								
								num2is = textField.getText();
								num2id = Double.parseDouble(num2is);
								textField.setText("");
								lblNewLabel.setText("Introducir valor en z");
															
	
								
							}else if(cont == 2) {
								
								num2s = textField.getText();
								num2d = Double.parseDouble(num2s);
								textField.setText("");
								lblNewLabel.setText("Unidades a mover");
								
							}else if(cont == 3) {
								
								num1is = textField.getText();
								num1id = Double.parseDouble(num1is);
								textField.setText("");
								Punto3D pt1 = new Punto3D(num1d,num2id,num2d);
								lblNewLabel.setText("Resultado: (" + pt1.moverX(pt1,num1id)+","+pt1.getY()+","+pt1.getZ()+")");
								cont = 0;
								
							} 
							cont++;

						}

					}
				});
				
				
			}
		});
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(255, 127, 127));
		btnNewButton.setFont(new Font("Microsoft JhengHei Light", Font.PLAIN, 12));
		btnNewButton.setBounds(10, 140, 188, 60);
		btnNewButton.setBorderPainted(false);
		frame.getContentPane().add(btnNewButton);
		
		btnNewButton_1 = new JButton("Mover en y");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lblNewLabel.setText("Introducir valor en x");
				lblNewLabel.setFont(new Font("Microsoft JhengHei Light", Font.PLAIN, 12));

				textField.addKeyListener(new KeyAdapter() {
					@Override
					public void keyPressed(KeyEvent e) {

						if (e.getKeyCode() == KeyEvent.VK_ENTER) {
							System.out.println("Entre event key"+cont);
							// Enter was pressed. Your code goes here.
							if (cont == 0) {
								
								num1s = textField.getText();
								num1d = Double.parseDouble(num1s);
								textField.setText("");
								lblNewLabel.setText("Introducir valor en y");

							} else if (cont == 1) {

								
								num2is = textField.getText();
								num2id = Double.parseDouble(num2is);
								textField.setText("");
								lblNewLabel.setText("Introducir valor en z");
															
	
								
							}else if(cont == 2) {
								
								num2s = textField.getText();
								num2d = Double.parseDouble(num2s);
								textField.setText("");
								lblNewLabel.setText("Unidades a mover");
								
							}else if(cont == 3) {
								
								num1is = textField.getText();
								num1id = Double.parseDouble(num1is);
								textField.setText("");
								Punto3D pt1 = new Punto3D(num1d,num2id,num2d);
								lblNewLabel.setText("Resultado: (" + pt1.getX()+","+pt1.moverY(pt1,num1id)+","+pt1.getZ()+")");
								cont = 0;
								
							} 
							cont++;

						}

					}
				});
				
				
				
			}
		});
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setFont(new Font("Microsoft JhengHei Light", Font.PLAIN, 12));
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.setBackground(new Color(255, 127, 127));
		btnNewButton_1.setBounds(10, 200, 188, 60);
		frame.getContentPane().add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("Mover en x & y & z");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lblNewLabel.setText("Introducir valor en x");
				lblNewLabel.setFont(new Font("Microsoft JhengHei Light", Font.PLAIN, 12));

				textField.addKeyListener(new KeyAdapter() {
					@Override
					public void keyPressed(KeyEvent e) {

						if (e.getKeyCode() == KeyEvent.VK_ENTER) {
							System.out.println("Entre event key"+cont);
							// Enter was pressed. Your code goes here.
							if (cont == 0) {
								
								num1s = textField.getText();
								num1d = Double.parseDouble(num1s);
								textField.setText("");
								lblNewLabel.setText("Introducir valor en y");

							} else if (cont == 1) {

								
								num2s = textField.getText();
								num2d = Double.parseDouble(num2s);
								textField.setText("");
								lblNewLabel.setText("Introducir valor en z");
															
	
								
							}else if(cont == 2) {
								
								num3is = textField.getText();
								num3id = Double.parseDouble(num3is);
								textField.setText("");
								lblNewLabel.setText("Unidades a mover en x");
								
								
							} else  if(cont == 3) {
								
								num1is = textField.getText();
								num1id = Double.parseDouble(num1is);
								textField.setText("");
								lblNewLabel.setText("Unidades a mover en y");
								
							}else if(cont == 4) {
								
								num4is = textField.getText();
								num4id = Double.parseDouble(num4is);
								textField.setText("");
								lblNewLabel.setText("Unidades a mover en z");
								
								
							}else if(cont == 5) {
								
								num2is = textField.getText();
								num2id = Double.parseDouble(num2is);
								Punto3D pt1 = new Punto3D(num1d,num2d,num3id);
								lblNewLabel.setText("Resultado: " + pt1.moverXYZ(pt1,num1id,num2id,num4id));
								cont = 0;
								
								
							}
							cont++;

						}

					}
				});
				
				
				
				
				
			}
		});
		btnNewButton_2.setForeground(new Color(255, 255, 255));
		btnNewButton_2.setFont(new Font("Microsoft JhengHei Light", Font.PLAIN, 12));
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setBackground(new Color(255, 127, 127));
		btnNewButton_2.setBounds(10, 320, 188, 60);
		frame.getContentPane().add(btnNewButton_2);
		
		btnDistancia = new JButton("Distancia entre puntos");
		btnDistancia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				

				lblNewLabel.setText("1er punto: Introducir valor en x");
				lblNewLabel.setFont(new Font("Microsoft JhengHei Light", Font.PLAIN, 12));

				textField.addKeyListener(new KeyAdapter() {
					@Override
					public void keyPressed(KeyEvent e) {

						if (e.getKeyCode() == KeyEvent.VK_ENTER) {
							System.out.println("Entre event key"+cont);
							// Enter was pressed. Your code goes here.
							if (cont == 0) {
								
								num1s = textField.getText();
								num1d = Double.parseDouble(num1s);
								textField.setText("");
								lblNewLabel.setText("1er punto: Introducir valor en y");

							} else if (cont == 1) {

								lblNewLabel
										.setText("1er punto: Introducir valor en z");
								num2s = textField.getText();
								num2d = Double.parseDouble(num2s);
								textField.setText("");
	

							}else if(cont == 2) {
								
								lblNewLabel.setText(
										"2do punto: Introducir valor en x");
								num3is = textField.getText();
								num3id = Double.parseDouble(num3is);
								textField.setText("");
								
								
							}   else if (cont == 3) {
								lblNewLabel.setText(
										"2do punto: Introducir valor en y");
								num1is = textField.getText();
								num1id = Double.parseDouble(num1is);
								textField.setText("");


							} else if (cont == 4) {

								num2is = textField.getText(); 
								num2id = Double.parseDouble(num2is);
								textField.setText("");
								
								
								//lblNewLabel.setText("Resultado: " + num1.suma(num1, num2));

							}else if(cont == 5) {
								
								num4is = textField.getText(); 
								num4id = Double.parseDouble(num4is);
								textField.setText("");
								lblNewLabel.setText(
										"2do punto: Introducir valor en z");
								
								Punto3D pt1 = new Punto3D(num1d,num2d,num3id);
								Punto3D pt2 = new Punto3D(num1id,num2id,num4id);
								
								lblNewLabel.setText("Resultado: " + pt1.dist(pt1, pt2));
								
								cont = 0;
								
							} 
							cont++;

						}

					}
				});
			}
		});
		btnDistancia.setForeground(new Color(255, 255, 255));
		btnDistancia.setFont(new Font("Microsoft JhengHei Light", Font.PLAIN, 12));
		btnDistancia.setBorderPainted(false);
		btnDistancia.setBackground(new Color(255, 156, 156));
		btnDistancia.setBounds(198, 140, 188, 60);
		frame.getContentPane().add(btnDistancia);
		
		btnDistanciaAlOrigen = new JButton("Distancia al origen");
		btnDistanciaAlOrigen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				

				lblNewLabel.setText("1er punto: Introducir valor en x");
				lblNewLabel.setFont(new Font("Microsoft JhengHei Light", Font.PLAIN, 12));

				textField.addKeyListener(new KeyAdapter() {
					@Override
					public void keyPressed(KeyEvent e) {

						if (e.getKeyCode() == KeyEvent.VK_ENTER) {
							System.out.println("Entre event key"+cont);
							// Enter was pressed. Your code goes here.
							if (cont == 0) {
								
								num1s = textField.getText();
								num1d = Double.parseDouble(num1s);
								textField.setText("");
								lblNewLabel.setText("1er punto: Introducir valor en y");

							} else if (cont == 1) {

								
								num2s = textField.getText();
								num2d = Double.parseDouble(num2s);
								textField.setText("");
								
									
								
								
	
								
							}else if (cont == 2) {
								
								num1is = textField.getText();
								num1id = Double.parseDouble(num1is);
								textField.setText("");
								
									Punto3D pt1 = new Punto3D(num1d,num2d,num1id);
								
								
								lblNewLabel.setText("Resultado: " + pt1.distOri(pt1));
								cont = 0;
								
								
								
							} 
							cont++;

						}

					}
				});
				
				
				
			}
		});
		btnDistanciaAlOrigen.setForeground(new Color(255, 255, 255));
		btnDistanciaAlOrigen.setFont(new Font("Microsoft JhengHei Light", Font.PLAIN, 12));
		btnDistanciaAlOrigen.setBorderPainted(false);
		btnDistanciaAlOrigen.setBackground(new Color(255, 156, 156));
		btnDistanciaAlOrigen.setBounds(198, 200, 188, 60);
		frame.getContentPane().add(btnDistanciaAlOrigen);
		
		btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lblNewLabel.setText("Escoja una operaci�n");
				textField.setText("");
				
				
			}
		});
		btnClear.setForeground(new Color(255, 255, 255));
		btnClear.setFont(new Font("Microsoft JhengHei Light", Font.PLAIN, 12));
		btnClear.setBorderPainted(false);
		btnClear.setBackground(new Color(255, 170, 170));
		btnClear.setBounds(198, 260, 188, 60);
		frame.getContentPane().add(btnClear);
		
		btnNewButton_3 = new JButton("Mover en z");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lblNewLabel.setText("Introducir valor en x");
				lblNewLabel.setFont(new Font("Microsoft JhengHei Light", Font.PLAIN, 12));

				textField.addKeyListener(new KeyAdapter() {
					@Override
					public void keyPressed(KeyEvent e) {

						if (e.getKeyCode() == KeyEvent.VK_ENTER) {
							System.out.println("Entre event key"+cont);
							// Enter was pressed. Your code goes here.
							if (cont == 0) {
								
								num1s = textField.getText();
								num1d = Double.parseDouble(num1s);
								textField.setText("");
								lblNewLabel.setText("Introducir valor en y");

							} else if (cont == 1) {

								
								num2is = textField.getText();
								num2id = Double.parseDouble(num2is);
								textField.setText("");
								lblNewLabel.setText("Introducir valor en z");
															
	
								
							}else if(cont == 2) {
								
								num2s = textField.getText();
								num2d = Double.parseDouble(num2s);
								textField.setText("");
								lblNewLabel.setText("Unidades a mover");
								
							}else if(cont == 3) {
								
								num1is = textField.getText();
								num1id = Double.parseDouble(num1is);
								textField.setText("");
								Punto3D pt1 = new Punto3D(num1d,num2id,num2d);
								lblNewLabel.setText("Resultado: (" + pt1.getX()+","+pt1.getY()+","+pt1.moverZ(pt1,num1id)+")");
								cont = 0;
								
							} 
							cont++;

						}

					}
				});
				
				
				
				
			}
		});
		btnNewButton_3.setForeground(Color.WHITE);
		btnNewButton_3.setFont(new Font("Microsoft JhengHei Light", Font.PLAIN, 12));
		btnNewButton_3.setBorderPainted(false);
		btnNewButton_3.setBackground(new Color(255, 127, 127));
		btnNewButton_3.setBounds(10, 260, 188, 60);
		frame.getContentPane().add(btnNewButton_3);
		
		panel_3 = new JPanel();
		panel_3.setBounds(198, 320, 188, 60);
		panel_3.setBackground(new Color(255, 170, 170));
		frame.getContentPane().add(panel_3);
		
		
		
		
	}
}
