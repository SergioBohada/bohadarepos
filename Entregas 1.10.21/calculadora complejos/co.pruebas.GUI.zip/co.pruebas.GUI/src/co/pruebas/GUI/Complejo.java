package co.pruebas.GUI;

import java.util.Scanner;


public class Complejo {
	
	private double real;
	private double compl;
	private static Complejo res;
	
	public Complejo(double real, double compl) {
		
		this.real = real;
		this.compl = compl;		
		
		
		
	}
	public Complejo() {
			
		
		
		
	}
	
	public double getReal() {
		
		return this.real;
		
	}
	
	
	public  String suma(Complejo uno, Complejo dos) {
		
		
		res = new Complejo(uno.real + dos.real,uno.compl+dos.compl);
		
		
		return res.compl <0 ? "("+String.valueOf(res.real)+String.valueOf(res.compl)+"i"+")":"("+String.valueOf(res.real)+"+"+String.valueOf(res.compl)+"i"+")";
		
	
		
				
	}
	
	public  String resta(Complejo uno, Complejo dos) {
		
		res = new Complejo((uno.real) - (dos.real),(uno.compl)-(dos.compl));
		
		
		return res.compl <0 ? "("+String.valueOf(res.real)+String.valueOf(res.compl)+"i"+")":"("+String.valueOf(res.real)+"+"+String.valueOf(res.compl)+"i"+")";
		
				
	}
	public  Complejo mult(Complejo uno, Complejo dos) {
		
		res = new Complejo(uno.real*dos.real,uno.compl*dos.compl);
		
		
		return res;
		
				
	}
	
	public  String mult2(Complejo uno, Complejo dos) {
		
		res = new Complejo(uno.real*dos.real,uno.compl*dos.compl);
		
		
		return res.compl <0 ? "("+String.valueOf(res.real)+String.valueOf(res.compl)+"i"+")":"("+String.valueOf(res.real)+"+"+String.valueOf(res.compl)+"i"+")";
		
				
	}
	public  Complejo cpm(Complejo uno) {
		
		res = new Complejo(uno.real, uno.compl*(-1));
		
		
		return res;
		
				
	}
	
	public  String cpm2(Complejo uno) {
		
		res = new Complejo(uno.real, uno.compl*(-1));
		
		
		return res.compl <0 ? "("+String.valueOf(res.real)+String.valueOf(res.compl)+"i"+")":"("+String.valueOf(res.real)+"+"+String.valueOf(res.compl)+"i"+")";
		
				
	}
	public String div(Complejo uno, Complejo dos) {
		 Complejo div = this.mult(uno,this.cpm(dos));
		 Complejo div2 = this.mult(dos, this.cpm(dos));
		 Complejo res = new Complejo(div.real/div2.real,div.compl/div2.real);
		  
		 return res.compl <0 ? "("+String.valueOf(res.real)+String.valueOf(res.compl)+"i"+")":"("+String.valueOf(res.real)+"+"+String.valueOf(res.compl)+"i"+")";
		 
		}
	
	public void leer(){
		   System.out.println("ingrese la parte real y la parte imaginaria");
		   Scanner s = new Scanner(System.in);
		   this.real=s.nextDouble();
		   this.compl=s.nextDouble();
		}
	
	 public void imprimir(Complejo c){
		  System.out.println(c.real+"+"+c.compl+"i");
		}

}
