package co_RelojDigital_UD;

public class Hora extends UT {
	
	public Hora(int limite, int valor) {
		super(limite, valor);
		
	}

}
