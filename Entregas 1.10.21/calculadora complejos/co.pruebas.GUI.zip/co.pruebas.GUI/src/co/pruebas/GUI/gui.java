package co.pruebas.GUI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.JTextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class gui {

	private String num1s;
	private double num1d;
	private String num2s;
	private double num2d;
	private String num1is;
	private double num1id;
	private String num2is;
	private double num2id;
	private int cont = 0;

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					gui window = new gui();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public gui() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		frame = new JFrame();
		frame.setBounds(100, 100, 632, 893);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("Oprima la operaci\u00F3n que quiere realizar");
		lblNewLabel_1.setFont(new Font("Arial Narrow", Font.PLAIN, 23));
		lblNewLabel_1.setBackground(new Color(51, 204, 102));
		lblNewLabel_1.setBounds(33, 55, 544, 87);
		frame.getContentPane().add(lblNewLabel_1);

		textField = new JTextField();
		textField.setBackground(new Color(204, 255, 204));
		textField.setBounds(159, 153, 299, 45);
		frame.getContentPane().add(textField);
		textField.setColumns(10);

		/*
		 * JLabel lblNewLabel_1_1 = new
		 * JLabel("Ingrese la parte real seguida de la imaginaria de los dos numeros");
		 * lblNewLabel_1_1.setFont(new Font("Arial Narrow", Font.PLAIN, 23));
		 * lblNewLabel_1_1.setBackground(new Color(51, 204, 102));
		 * lblNewLabel_1_1.setBounds(146, 55, 329, 87);
		 */

		JButton btnNewButton = new JButton("1");
		btnNewButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				textField.setText(textField.getText()+"1");
			}
		});
		btnNewButton.setBounds(53, 274, 87, 87);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setBorderPainted(false);
		btnNewButton.setFocusPainted(false);

		frame.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("2");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				textField.setText(textField.getText()+"2");
			}
		});
		btnNewButton_1.setFocusPainted(false);
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setBounds(195, 274, 87, 87);
		frame.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("3");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"3");
			}
		});
		btnNewButton_2.setFocusPainted(false);
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setBounds(53, 426, 87, 87);
		frame.getContentPane().add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("4");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				textField.setText(textField.getText()+"4");
				
			}
		});
		btnNewButton_3.setFocusPainted(false);
		btnNewButton_3.setBorderPainted(false);
		btnNewButton_3.setBackground(Color.WHITE);
		btnNewButton_3.setBounds(195, 426, 87, 87);
		frame.getContentPane().add(btnNewButton_3);

		JButton btnNewButton_4 = new JButton("5");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				textField.setText(textField.getText()+"5");
			}
		});
		btnNewButton_4.setFocusPainted(false);
		btnNewButton_4.setBorderPainted(false);
		btnNewButton_4.setBackground(Color.WHITE);
		btnNewButton_4.setBounds(333, 426, 87, 87);
		frame.getContentPane().add(btnNewButton_4);

		JButton btnNewButton_5 = new JButton("6");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"6");
			}
		});
		btnNewButton_5.setFocusPainted(false);
		btnNewButton_5.setBorderPainted(false);
		btnNewButton_5.setBackground(Color.WHITE);
		btnNewButton_5.setBounds(53, 568, 87, 87);
		frame.getContentPane().add(btnNewButton_5);

		JButton btnNewButton_6 = new JButton("7");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"7");
			}
		});
		btnNewButton_6.setFocusPainted(false);
		btnNewButton_6.setBorderPainted(false);
		btnNewButton_6.setBackground(Color.WHITE);
		btnNewButton_6.setBounds(195, 568, 87, 87);
		frame.getContentPane().add(btnNewButton_6);

		JButton btnNewButton_7 = new JButton("8");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"8");
			}
		});
		btnNewButton_7.setFocusPainted(false);
		btnNewButton_7.setBorderPainted(false);
		btnNewButton_7.setBackground(Color.WHITE);
		btnNewButton_7.setBounds(333, 568, 87, 87);
		frame.getContentPane().add(btnNewButton_7);

		JButton btnNewButton_8 = new JButton("9");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"9");
			}
		});
		btnNewButton_8.setFocusPainted(false);
		btnNewButton_8.setBorderPainted(false);
		btnNewButton_8.setBackground(Color.WHITE);
		btnNewButton_8.setBounds(53, 712, 87, 87);
		frame.getContentPane().add(btnNewButton_8);

		JButton btnNewButton_9 = new JButton("0");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(textField.getText()+"0");
			}
		});
		btnNewButton_9.setFocusPainted(false);
		btnNewButton_9.setBorderPainted(false);
		btnNewButton_9.setBackground(Color.WHITE);
		btnNewButton_9.setBounds(195, 712, 87, 87);
		frame.getContentPane().add(btnNewButton_9);

		JButton btnNewButton_9_1 = new JButton("+");
		btnNewButton_9_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				lblNewLabel_1.setText("Introducir parte real del primer n�mero (Enter para continuar)");

				textField.addKeyListener(new KeyAdapter() {
					@Override
					public void keyPressed(KeyEvent e) {

						if (e.getKeyCode() == KeyEvent.VK_ENTER) {
							System.out.println("Entre event key"+cont);
							// Enter was pressed. Your code goes here.
							if (cont == 0) {
								System.out.println("entre if conta ");

								num1s = textField.getText();
								num1d = Double.parseDouble(num1s);
								System.out.println("parte real 1"+num1d);
								textField.setText("");
								lblNewLabel_1.setText("Introducir parte imaginaria del primer n�mero (Enter para continuar)");

							} else if (cont == 1) {

								lblNewLabel_1
										.setText("Introducir parte real del segundo n�mero (Enter para continuar)");
								num2s = textField.getText();
								num2d = Double.parseDouble(num2s);
								textField.setText("");
	

							} else if (cont == 2) {
								lblNewLabel_1.setText(
										"Introducir parte imaginaria del segundo n�mero (Enter para continuar)");
								num1is = textField.getText();
								num1id = Double.parseDouble(num1is);
								textField.setText("");


							} else if (cont == 3) {

								num2is = textField.getText(); 
								num2id = Double.parseDouble(num2is);
								textField.setText("");
								
								
								Complejo num1 = new Complejo(num1d, num2d);
								Complejo num2 = new Complejo(num1id, num2id);
								
								cont = 0;
								lblNewLabel_1.setText("Resultado: " + num1.suma(num1, num2));

							} 
							cont++;

						}

					}
				});

				
				 
			}
		});
		btnNewButton_9_1.setFocusPainted(false);
		btnNewButton_9_1.setBorderPainted(false);
		btnNewButton_9_1.setBackground(Color.WHITE);
		btnNewButton_9_1.setBounds(475, 426, 87, 87);
		frame.getContentPane().add(btnNewButton_9_1);

		JButton btnNewButton_9_2 = new JButton("-");
		btnNewButton_9_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lblNewLabel_1.setText("Introducir parte real del primer n�mero (Enter para continuar)");

				textField.addKeyListener(new KeyAdapter() {
					@Override
					public void keyPressed(KeyEvent e) {

						if (e.getKeyCode() == KeyEvent.VK_ENTER) {
							// Enter was pressed. Your code goes here.
							if (cont == 0) {
						
								num1s = textField.getText();
								num1d = Double.parseDouble(num1s);
								textField.setText("");
								lblNewLabel_1.setText("Introducir parte imaginaria del primer n�mero (Enter para continuar)");

							} else if (cont == 1) {

								lblNewLabel_1
										.setText("Introducir parte real del segundo n�mero (Enter para continuar)");
								num2s = textField.getText();
								num2d = Double.parseDouble(num2s);
								textField.setText("");

							} else if (cont == 2) {
								lblNewLabel_1.setText(
										"Introducir parte imaginaria del segundo n�mero (Enter para continuar)");
								num1is = textField.getText();
								num1id = Double.parseDouble(num1is);
								textField.setText("");


							} else if (cont == 3) {

								num2is = textField.getText();
								num2id = Double.parseDouble(num2is);
								textField.setText("");

								
								Complejo num1 = new Complejo(num1d, num2d);
								Complejo num2 = new Complejo(num1id, num2id);
								
								cont = 0;
								lblNewLabel_1.setText("Resultado: " + num1.resta(num1, num2));

							} 
							cont++;

						}

					}
				});

				
				
				
			}
		});
		btnNewButton_9_2.setFocusPainted(false);
		btnNewButton_9_2.setBorderPainted(false);
		btnNewButton_9_2.setBackground(Color.WHITE);
		btnNewButton_9_2.setBounds(475, 568, 87, 87);
		frame.getContentPane().add(btnNewButton_9_2);

		JButton btnNewButton_9_3 = new JButton("/");
		btnNewButton_9_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lblNewLabel_1.setText("Introducir parte real del primer n�mero (Enter para continuar)");

				textField.addKeyListener(new KeyAdapter() {
					@Override
					public void keyPressed(KeyEvent e) {

						if (e.getKeyCode() == KeyEvent.VK_ENTER) {
							// Enter was pressed. Your code goes here.
							if (cont == 0) {
						
								num1s = textField.getText();
								num1d = Double.parseDouble(num1s);
								textField.setText("");
								lblNewLabel_1.setText("Introducir parte imaginaria del primer n�mero (Enter para continuar)");

							} else if (cont == 1) {

								lblNewLabel_1
										.setText("Introducir parte real del segundo n�mero (Enter para continuar)");
								num2s = textField.getText();
								num2d = Double.parseDouble(num2s);
								textField.setText("");

							} else if (cont == 2) {
								lblNewLabel_1.setText(
										"Introducir parte imaginaria del segundo n�mero (Enter para continuar)");
								num1is = textField.getText();
								num1id = Double.parseDouble(num1is);
								textField.setText("");


							} else if (cont == 3) {

								num2is = textField.getText();
								num2id = Double.parseDouble(num2is);
								textField.setText("");
								
								
								Complejo num1 = new Complejo(num1d, num2d);
								Complejo num2 = new Complejo(num1id, num2id);
								
								cont = 0;
								lblNewLabel_1.setText("Resultado: " + num1.div(num1, num2));

							} 
							cont++;

						}

					}
				});

				
				
			}
		});
		btnNewButton_9_3.setFocusPainted(false);
		btnNewButton_9_3.setBorderPainted(false);
		btnNewButton_9_3.setBackground(Color.WHITE);
		btnNewButton_9_3.setBounds(333, 712, 87, 87);
		frame.getContentPane().add(btnNewButton_9_3);

		JButton btnNewButton_9_4 = new JButton("x");
		btnNewButton_9_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lblNewLabel_1.setText("Introducir parte real del primer n�mero (Enter para continuar)");

				textField.addKeyListener(new KeyAdapter() {
					@Override
					public void keyPressed(KeyEvent e) {

						if (e.getKeyCode() == KeyEvent.VK_ENTER) {
							// Enter was pressed. Your code goes here.
							if (cont == 0) {
						
								num1s = textField.getText();
								num1d = Double.parseDouble(num1s);
								textField.setText("");
								lblNewLabel_1.setText("Introducir parte imaginaria del primer n�mero (Enter para continuar)");

							} else if (cont == 1) {

								lblNewLabel_1
										.setText("Introducir parte real del segundo n�mero (Enter para continuar)");
								num2s = textField.getText();
								num2d = Double.parseDouble(num2s);
								textField.setText("");

							} else if (cont == 2) {
								lblNewLabel_1.setText(
										"Introducir parte imaginaria del segundo n�mero (Enter para continuar)");
								num1is = textField.getText();
								num1id = Double.parseDouble(num1is);
								textField.setText("");


							} else if (cont == 3) {

								num2is = textField.getText();
								num2id = Double.parseDouble(num2is);
								textField.setText("");
								
								
								Complejo num1 = new Complejo(num1d, num2d);
								Complejo num2 = new Complejo(num1id, num2id);
								
								cont = 0;
								lblNewLabel_1.setText("Resultado: " + num1.mult2(num1, num2));

							} 
							cont++;

						}

					}
				});

				
				
				
			}
		});
		btnNewButton_9_4.setFocusPainted(false);
		btnNewButton_9_4.setBorderPainted(false);
		btnNewButton_9_4.setBackground(Color.WHITE);
		btnNewButton_9_4.setBounds(475, 712, 87, 87);
		frame.getContentPane().add(btnNewButton_9_4);

		JButton btnNewButton_9_4_1 = new JButton("Con");
		btnNewButton_9_4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lblNewLabel_1.setText("Introducir parte real del primer n�mero (Enter para continuar)");

				textField.addKeyListener(new KeyAdapter() {
					@Override
					public void keyPressed(KeyEvent e) {

						if (e.getKeyCode() == KeyEvent.VK_ENTER) {
							// Enter was pressed. Your code goes here.
							if (cont == 0) {
						
								num1s = textField.getText();
								num1d = Double.parseDouble(num1s);
								textField.setText("");
								lblNewLabel_1.setText("Introducir parte imaginaria del numero");

							} else if (cont == 1) {

								lblNewLabel_1
										.setText("Introducir parte real del numero");
								num2s = textField.getText();
								num2d = Double.parseDouble(num2s);
								textField.setText("");
								
								Complejo num1 = new Complejo(num1d, num2d);
	
								
								cont = 0;
								lblNewLabel_1.setText("Resultado: " + num1.cpm2(num1));

							}  
							cont++;

						}

					}
				});

				
				
				
			}
		});
		btnNewButton_9_4_1.setFocusPainted(false);
		btnNewButton_9_4_1.setBorderPainted(false);
		btnNewButton_9_4_1.setBackground(new Color(255, 153, 102));
		btnNewButton_9_4_1.setBounds(333, 274, 87, 87);
		frame.getContentPane().add(btnNewButton_9_4_1);

		JButton btnNewButton_9_4_1_1 = new JButton("Clear");
		btnNewButton_9_4_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
			}
		});
		btnNewButton_9_4_1_1.setFocusPainted(false);
		btnNewButton_9_4_1_1.setBorderPainted(false);
		btnNewButton_9_4_1_1.setBackground(new Color(255, 102, 102));
		btnNewButton_9_4_1_1.setBounds(475, 274, 87, 87);
		frame.getContentPane().add(btnNewButton_9_4_1_1);

		JLabel lblNewLabel = new JLabel();
		lblNewLabel.setBounds(0, 0, 616, 854);
		lblNewLabel.setIcon(new ImageIcon(gui.class.getResource("/co/pruebas/GUI/cal back 2.png")));
		frame.getContentPane().add(lblNewLabel);

	}
}
