package craps;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;

public class LoginFrame extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	private static LoginFrame frame;
	private final JLabel lblNewLabel_1 = new JLabel("New label");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					 frame = new LoginFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginFrame() {
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		getContentPane().setLayout(null);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Nombre Usuario:");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(37, 36, 116, 14);
		getContentPane().add(lblNewLabel);

		textField = new JTextField();
		textField.setBounds(169, 33, 126, 20);
		getContentPane().add(textField);
		textField.setColumns(10);

		JLabel lblContrasea = new JLabel("Contrase\u00F1a:");
		lblContrasea.setForeground(Color.WHITE);
		lblContrasea.setBounds(37, 68, 123, 14);
		getContentPane().add(lblContrasea);

		passwordField = new JPasswordField();
		passwordField.setBounds(169, 65, 126, 20);
		getContentPane().add(passwordField);

		JCheckBox showPassword = new JCheckBox("Mostrar contrase\u00F1a");
		showPassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (showPassword.isSelected()) {
	                passwordField.setEchoChar((char) 0);
	            } else {
	                passwordField.setEchoChar('*');
	            }
			}
		});
		showPassword.setBounds(171, 97, 169, 23);
		getContentPane().add(showPassword);

		JButton btnNewButton = new JButton("Iniciar sesi\u00F3n");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String userText;
	            String pwdText;
	            userText = textField.getText();
	            pwdText = passwordField.getText();
	            if (userText.equalsIgnoreCase("john") && pwdText.equalsIgnoreCase("12345")) {
	                JOptionPane.showMessageDialog(frame, "Login Successful");
	                frame.dispose();
					new GameFrame(userText, pwdText, 100);
	            } else {
	                JOptionPane.showMessageDialog(frame, "Invalid Username or Password");
	            }
				
			}
		});
		btnNewButton.setBounds(57, 143, 126, 23);
		getContentPane().add(btnNewButton);

		JButton btnResetear = new JButton("Resetear");
		btnResetear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
	            passwordField.setText("");
			}
		});
		btnResetear.setBounds(205, 143, 126, 23);
		getContentPane().add(btnResetear);

		JButton btnRegistrarse = new JButton("Registrarse");
		btnRegistrarse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				new SignUpFrame();
			}
		});
		btnRegistrarse.setBounds(128, 177, 132, 23);
		getContentPane().add(btnRegistrarse);
		lblNewLabel_1.setIcon(new ImageIcon(LoginFrame.class.getResource("/craps/fondo.jpg")));
		lblNewLabel_1.setBounds(0, 0, 447, 273);
		contentPane.add(lblNewLabel_1);
	}

}
