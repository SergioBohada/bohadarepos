package co_RelojDigital_UD;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class backgift extends Thread{
	
	RelojInter hl = new RelojInter();
	
	@Override
	public void run() {
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(RelojInter.class.getResource("/co_RelojDigital_UD/anime-lofi.gif")));
		lblNewLabel_1.setBounds(0, 0, 381, 428);
		hl.getFrame().getContentPane().add(lblNewLabel_1);
		
		
	}

}
