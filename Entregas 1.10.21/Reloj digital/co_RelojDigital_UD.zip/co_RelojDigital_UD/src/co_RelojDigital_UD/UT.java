package co_RelojDigital_UD;

import java.util.concurrent.TimeUnit;

public class UT {
	
	protected int limite;
	protected int valor;

	
	 public UT(int limite, int valor) {
		
		 this.valor = valor;
		 this.limite = limite;
		
		
	}
	 
	 public int getValor() {
		return valor;
	}

	public int getLimite() {
		return limite;
	}

	public void setLimite(int limite) {
		this.limite = limite;
	}

	public void setValor(int valor) {
		this.valor = valor;
	}

	public UT() {
		 
		 
	 }
	 
	 public void Avanzar() {
		 
		 
		 if(valor == limite-1) {
			 
			 valor = 0;
			 
		 }else {
			 
			 valor ++;
			 
			 
		 }
		 
		 
		 
	 }

}
