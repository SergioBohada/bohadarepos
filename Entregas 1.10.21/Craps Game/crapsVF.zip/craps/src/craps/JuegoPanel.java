package craps;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class JuegoPanel extends JPanel {
	private JTextField textApu;

	/**
	 * Create the panel.
	 */
	public JuegoPanel() {
		setLayout(null);
		
		JLabel lblDisp = new JLabel("$ Disponible:");
		lblDisp.setBounds(25, 11, 65, 14);
		add(lblDisp);
		
		JLabel lblDispVal = new JLabel("New label");
		lblDispVal.setBounds(91, 11, 49, 14);
		add(lblDispVal);
		
		JLabel lblJugador = new JLabel("Jugador");
		lblJugador.setBounds(363, 11, 49, 14);
		add(lblJugador);
		
		JLabel lblApu = new JLabel("Apuesta:");
		lblApu.setBounds(61, 83, 49, 14);
		add(lblApu);
		
		JLabel lblDados = new JLabel("Resultados:");
		lblDados.setBounds(226, 83, 59, 14);
		add(lblDados);
		
		textApu = new JTextField();
		textApu.setBounds(120, 80, 49, 20);
		add(textApu);
		textApu.setColumns(10);
		
		JLabel lblDadosVal = new JLabel("New label");
		lblDadosVal.setBounds(295, 83, 49, 14);
		add(lblDadosVal);
		
		JLabel lblRondaVal = new JLabel("1");
		lblRondaVal.setBounds(120, 153, 49, 14);
		add(lblRondaVal);
		
		JLabel lblRonda = new JLabel("Ronda #");
		lblRonda.setBounds(74, 153, 49, 14);
		add(lblRonda);
		
		JLabel lblEstado = new JLabel("Estado juego:");
		lblEstado.setBounds(216, 153, 69, 14);
		add(lblEstado);
		
		JLabel lblEstadoVal = new JLabel("New label");
		lblEstadoVal.setBounds(295, 153, 49, 14);
		add(lblEstadoVal);
		
		JButton btnNewButton = new JButton("Siguiente ronda");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String apuesta = textApu.getText();
				double ap = Double.parseDouble(apuesta);
				
				
				
			}
		});
		btnNewButton.setBounds(61, 214, 121, 20);
		add(btnNewButton);
		
		JButton btnRetirarse = new JButton("Retirarse");
		btnRetirarse.setBounds(211, 213, 121, 20);
		add(btnRetirarse);

	}
}
